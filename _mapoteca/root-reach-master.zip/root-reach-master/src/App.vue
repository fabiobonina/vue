<template>
  <v-app id="app" standalone>
    <router-view></router-view>
  </v-app>
</template>

<script>
export default {
  name: 'app'
}
</script>

<style lang="stylus"
  @import './stylus/main'>
</style>
